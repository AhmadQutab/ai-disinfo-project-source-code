"""Qualitative risk matrix (Section 5.3). Scores are analyst judgements, not measurements."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Scenario:
    sid: str
    description: str
    likelihood: int  # 1-5
    impact: int      # 1-5
    basis: str

    @property
    def score(self):
        return self.likelihood * self.impact

    @property
    def rating(self):
        return "High" if self.score >= 15 else "Medium" if self.score >= 10 else "Lower"


SCENARIOS = [
    Scenario("S1", "Election-eve synthetic audio/video of a candidate or official", 4, 4, "C5, C7"),
    Scenario("S2", "Voice/video-clone fraud against organisations and families", 5, 3, "C9"),
    Scenario("S3", "Automated LLM persona networks for persuasion and harassment", 4, 3, "C3, C10, C13"),
    Scenario("S4", "Fabricated crisis imagery triggering panic or market moves", 3, 4, "C4"),
    Scenario("S5", "Authentic evidence dismissed as fake (liar's dividend)", 4, 3, "C1"),
    Scenario("S6", "Wartime deepfake of a leader issuing false orders", 2, 5, "C2"),
    Scenario("S7", "Hyper-personalised persuasion at scale", 3, 3, "Literature"),
]


def ranked(scenarios=SCENARIOS):
    return sorted(scenarios, key=lambda s: s.score, reverse=True)
