"""Prototype of the disinformation triage workflow (Section 6.2).

Stages: ingest -> provenance check -> analysis -> prioritisation -> human review queue.
This is a TRIAGE aid: it ranks items for human analysts and explains why. It never
decides that content is false. All heuristics are simple and transparent by design.
"""
import re
from dataclasses import dataclass, field
from typing import Optional

STOP = set("the a an of to in on and or is are was were for with at by from this that it as be".split())

URGENCY_TERMS = {
    "breaking", "urgent", "shocking", "exposed", "leaked", "banned", "cover-up", "coverup",
    "share before", "they don't want you to know", "must watch", "immediately", "bombshell",
}
ELECTION_TERMS = {
    "vote", "voting", "ballot", "ballots", "polling", "polls", "election", "candidate",
    "rigged", "rigging", "turnout", "primary", "results",
}

# Small illustrative "known false claims" list. In a real system this would be a
# fact-checker database lookup (e.g. a claim-matching API).
KNOWN_FALSE_CLAIMS = {
    "FC-001": "polling stations closed early voting postponed tomorrow",
    "FC-002": "explosion reported near government building",
    "FC-003": "leader orders troops to surrender",
}


@dataclass
class Item:
    id: str
    text: str
    account: str = "unknown"
    account_age_days: Optional[int] = None
    posts_per_day: Optional[float] = None
    media_type: str = "text"                   # text | image | audio | video
    content_credentials: Optional[str] = None  # valid | missing | invalid | None
    shares_last_hour: int = 0


@dataclass
class Result:
    item_id: str
    priority: float
    tier: str
    reasons: list = field(default_factory=list)


def tokens(text):
    words = re.findall(r"[a-z0-9']+", text.lower())
    return {w for w in words if w not in STOP and len(w) > 2}


def jaccard(a, b):
    return len(a & b) / len(a | b) if a and b else 0.0


# ---- individual signals; each returns (points, reason or None) ----

def provenance_signal(item):
    if item.media_type == "text":
        return 0, None
    cc = item.content_credentials
    if cc == "valid":
        return -10, "valid content credentials (authenticity signal)"
    if cc == "invalid":
        return 25, "content credentials present but fail validation"
    return 12, f"{item.media_type} with no verifiable provenance"


def language_signal(item):
    t = item.text.lower()
    hits = [w for w in URGENCY_TERMS if w in t]
    caps = len(re.findall(r"\b[A-Z]{4,}\b", item.text))
    pts = min(15, 5 * len(hits) + 2 * min(caps, 3))
    return pts, (f"sensational/urgent language ({', '.join(hits) or 'ALL-CAPS'})" if pts else None)


def claim_signal(item):
    toks = tokens(item.text)
    best = max(((jaccard(toks, tokens(c)), cid) for cid, c in KNOWN_FALSE_CLAIMS.items()),
               default=(0, None))
    if best[0] >= 0.3:
        return 30, f"matches known false claim {best[1]} (similarity {best[0]:.2f})"
    return 0, None


def account_signal(item):
    pts, why = 0, []
    if item.account_age_days is not None and item.account_age_days < 30:
        pts += 8
        why.append(f"new account ({item.account_age_days} days)")
    if item.posts_per_day is not None and item.posts_per_day > 50:
        pts += 8
        why.append(f"very high posting rate ({item.posts_per_day:.0f}/day)")
    return pts, ("; ".join(why) if why else None)


def velocity_signal(item):
    pts = min(15, item.shares_last_hour // 200 * 3)
    return pts, (f"fast spread ({item.shares_last_hour} shares in last hour)" if pts else None)


def election_signal(item):
    hits = tokens(item.text) & ELECTION_TERMS
    return (10, "election-related content (time-critical)") if hits else (0, None)


def coordination_signal(item, batch, threshold=0.8):
    """Near-duplicate text from different accounts within the batch."""
    mine = tokens(item.text)
    others = [o for o in batch if o.id != item.id and o.account != item.account
              and jaccard(mine, tokens(o.text)) >= threshold]
    if others:
        return min(20, 8 + 4 * len(others)), f"near-duplicate text from {len(others)} other account(s)"
    return 0, None


SIGNALS = [provenance_signal, language_signal, claim_signal, account_signal,
           velocity_signal, election_signal]


def score_item(item, batch):
    total, reasons = 0, []
    for sig in SIGNALS + [lambda i: coordination_signal(i, batch)]:
        pts, why = sig(item)
        total += pts
        if why:
            reasons.append(f"{why} [{pts:+d}]")
    total = max(0, min(100, total))
    tier = "ESCALATE" if total >= 60 else "REVIEW" if total >= 35 else "MONITOR"
    return Result(item.id, total, tier, reasons)


def triage(batch):
    """Return results sorted by priority (highest first) for the human review queue."""
    return sorted((score_item(i, batch) for i in batch), key=lambda r: r.priority, reverse=True)
