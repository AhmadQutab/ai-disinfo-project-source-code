"""Descriptive analysis of the coded incident register (Section 5.1 of the report)."""
import csv
from collections import Counter
from pathlib import Path

DATA = Path(__file__).resolve().parents[2] / "data" / "incidents.csv"


def load_incidents(path=DATA):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r["year"] = int(r["year"])
    return rows


def count_by(rows, field):
    """Counts of a coded variable, most common first."""
    return Counter(r[field] for r in rows).most_common()


def crosstab(rows, a, b):
    """Two-way table as {a_value: {b_value: count}}."""
    table = {}
    for r in rows:
        table.setdefault(r[a], Counter())[r[b]] += 1
    return {k: dict(v) for k, v in table.items()}


def plot_distribution(rows, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fields = [("modality", "By modality", "#1F3A5F"),
              ("actor_type", "By actor type", "#2E7D6B"),
              ("objective", "By objective", "#B5651D")]
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6), dpi=180)
    for ax, (field, title, color) in zip(axes, fields):
        items = count_by(rows, field)[::-1]
        labels, vals = [i[0] for i in items], [i[1] for i in items]
        ax.barh(labels, vals, color=color)
        ax.set_title(title, fontsize=10, fontweight="bold")
        ax.set_xlim(0, max(vals) + 1.5)
        ax.set_xticks([])
        ax.tick_params(labelsize=7.5)
        for y, v in enumerate(vals):
            ax.text(v + 0.1, y, str(v), va="center", fontsize=8)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close(fig)
