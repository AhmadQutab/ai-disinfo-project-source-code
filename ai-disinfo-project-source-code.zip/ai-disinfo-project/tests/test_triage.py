import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from disinfo.triage import Item, triage, jaccard, tokens
from disinfo import analysis, risk


class TriageTests(unittest.TestCase):
    def test_valid_credentials_lower_priority(self):
        a = Item("a", "Statement on polling hours", media_type="video", content_credentials="valid")
        b = Item("b", "Statement on polling hours", media_type="video", content_credentials="missing")
        res = {r.item_id: r.priority for r in triage([a, b])}
        self.assertLess(res["a"], res["b"])

    def test_known_false_claim_escalates(self):
        item = Item("x", "BREAKING polling stations closed early voting postponed tomorrow",
                    account_age_days=3, posts_per_day=100, shares_last_hour=800)
        self.assertEqual(triage([item])[0].tier, "ESCALATE")

    def test_benign_content_is_monitor(self):
        item = Item("y", "Recipe for biryani", account_age_days=900, posts_per_day=2)
        self.assertEqual(triage([item])[0].tier, "MONITOR")

    def test_coordination_detected(self):
        t = "same exact message about the vote being cancelled today"
        a, b = Item("a", t, account="@one"), Item("b", t, account="@two")
        reasons = " ".join(triage([a, b])[0].reasons)
        self.assertIn("near-duplicate", reasons)

    def test_same_account_not_coordination(self):
        t = "same exact message about the vote being cancelled today"
        a, b = Item("a", t, account="@one"), Item("b", t, account="@one")
        self.assertNotIn("near-duplicate", " ".join(triage([a, b])[0].reasons))

    def test_jaccard_bounds(self):
        self.assertEqual(jaccard(tokens("alpha beta gamma"), tokens("alpha beta gamma")), 1.0)
        self.assertEqual(jaccard(set(), {"x"}), 0.0)


class AnalysisTests(unittest.TestCase):
    def test_register_counts_match_report(self):
        rows = analysis.load_incidents()
        self.assertEqual(len(rows), 13)
        self.assertEqual(dict(analysis.count_by(rows, "modality"))["Video"], 5)
        self.assertEqual(dict(analysis.count_by(rows, "objective"))["Political / election influence"], 7)

    def test_risk_ratings(self):
        self.assertEqual(risk.ranked()[0].sid, "S1")
        self.assertEqual(risk.ranked()[0].rating, "High")


if __name__ == "__main__":
    unittest.main()
